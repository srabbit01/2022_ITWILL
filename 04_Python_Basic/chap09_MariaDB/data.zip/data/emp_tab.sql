-- table 만들기 
create or replace table emp(
eno int auto_increment primary key,
ename varchar(20) not null,
hiredate date not null,
sal int not null,
bonus int default 0,
job varchar(20) not null,
dno int);

-- auto increment: 자동번호생성기(시퀀스 기능 유사)

-- 사번 시작번호 변경: start=1, step=1
alter table emp auto_increment = 1001; -- start=1001

-- 레코드 추가 
insert into emp(ename, hiredate, sal, bonus, job, dno) 
values('홍길동','2008-10-20',300, 35,'관리자',10);
insert into emp(ename, hiredate, sal, bonus, job, dno) 
values('강호동', '2010-10-20', 250, 0,'사원', 20);
insert into emp(ename, hiredate, sal, bonus, job, dno) 
values('유관순', '2008-03-20', 200, 0,'사원', 10);
insert into emp(ename, hiredate, sal, bonus, job, dno) 
values('강감찬', '2007-01-20', 450, 100,'관리자', 20);
-- 레코드 조회 
SELECT * FROM emp;