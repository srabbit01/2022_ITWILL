create table zipcode_tab(
zipcode char(14) not null,
city varchar(15) not null,
gu varchar(20) not null,
dong varchar(60) not null,zipcode_tab
detail varchar(50)    
);

SELECT * FROM zipcode_tab;